package com.edplan.framework.timing;

public interface PassivityClock extends AbstractClock
{
	public void refresh(int t);
}
