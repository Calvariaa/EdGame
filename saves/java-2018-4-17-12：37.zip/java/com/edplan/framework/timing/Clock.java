package com.edplan.framework.timing;

public class Clock 
{
	
}
