package com.edplan.framework.timing;


public interface AbstractClock
{
	public double getTime();
}
