package com.edplan.framework.view;
import android.graphics.drawable.Drawable;
import android.graphics.ColorFilter;
import android.graphics.Canvas;

public interface MDrawable
{
	public void draw(Canvas canvas);
}
