package com.edplan.framework.view.staticField;
import com.edplan.framework.view.MStaticViewGroup;
import com.edplan.framework.view.MTextView;
import com.edplan.framework.view.MFlatButton;
import com.edplan.framework.MContext;

public class InforView extends MStaticViewGroup
{
	public MTextView textView;
	
	public InforView(MContext con){
		super(con);
	}
	
}
