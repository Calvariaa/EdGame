package com.edplan.framework.main;


/**
 *@Field : 屏幕管理
 *		   输入放缩
 *		   res管理
 *		   data管理
 *		   gl顶端
 *		   
 */
import com.edplan.framework.graphics.opengl.GLLooper;
import com.edplan.framework.graphics.layer.BufferedLayer;

public class GameContext 
{
	private GLLooper glLooper;
	
	private BufferedLayer rootLayer;
	
	
	
}
