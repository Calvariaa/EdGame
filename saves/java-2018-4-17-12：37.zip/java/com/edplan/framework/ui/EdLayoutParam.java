package com.edplan.framework.ui;

public class EdLayoutParam
{
}