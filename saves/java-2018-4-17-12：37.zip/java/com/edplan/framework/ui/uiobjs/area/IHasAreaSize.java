package com.edplan.framework.ui.uiobjs.area;

public interface IHasAreaSize
{
	public float getAreaSize();
}
