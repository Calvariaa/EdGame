package com.edplan.framework.ui.uiobjs;

public enum DrawRequestParam
{
	FullCanvas,NewLayer,TranslateCanvas
}
