package com.edplan.framework.ui.text.font;
import java.util.HashMap;
import com.edplan.framework.graphics.opengl.objs.AbstractTexture;

public class TextureFont
{
	public HashMap<Character,AbstractTexture> characterTextures;
	
	
}
