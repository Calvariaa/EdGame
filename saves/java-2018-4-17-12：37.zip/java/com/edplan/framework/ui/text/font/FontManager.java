package com.edplan.framework.ui.text.font;

/**
 *所有字体的管理类
 */
public class FontManager
{
	
}
