package com.edplan.framework.ui.text;
import com.edplan.framework.ui.drawable.EdDrawable;
import com.edplan.framework.graphics.opengl.GLCanvas2D;
import com.edplan.framework.MContext;

public class TextureTextDrawable extends EdDrawable
{
	
	
	public TextureTextDrawable(MContext context){
		super(context);
	}

	@Override
	public void draw(GLCanvas2D canvas) {
		// TODO: Implement this method
	}
}
