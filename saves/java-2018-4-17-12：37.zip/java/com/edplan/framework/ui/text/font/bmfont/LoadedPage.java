package com.edplan.framework.ui.text.font.bmfont;
import com.edplan.framework.graphics.opengl.objs.AbstractTexture;

public class LoadedPage
{
	public int id;
	
	public AbstractTexture texture;
}
