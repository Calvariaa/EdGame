package com.edplan.framework.ui.drawable.interfaces;

public interface IProgresser
{
	public void setProgress(float p);
	
	public float getProgress();
}
