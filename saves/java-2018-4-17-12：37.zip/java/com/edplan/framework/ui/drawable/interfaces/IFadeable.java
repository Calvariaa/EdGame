package com.edplan.framework.ui.drawable.interfaces;

public interface IFadeable
{
	public void setAlpha(float a);
	
	public float getAlpha();
}
