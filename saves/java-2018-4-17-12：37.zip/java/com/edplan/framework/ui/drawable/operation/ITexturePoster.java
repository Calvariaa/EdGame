package com.edplan.framework.ui.drawable.operation;
import com.edplan.framework.graphics.opengl.GLCanvas2D;
import com.edplan.framework.graphics.opengl.objs.GLTexture;

public interface ITexturePoster
{
	public void drawTexture(GLCanvas2D canvas,GLTexture t);
}
