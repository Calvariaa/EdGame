package com.edplan.framework.ui.drawable;
import com.edplan.framework.MContext;
import com.edplan.framework.graphics.opengl.GLCanvas2D;

public class FrameDrawable extends EdDrawable
{
	public FrameDrawable(MContext c){
		super(c);
	}

	@Override
	public void draw(GLCanvas2D canvas) {
		// TODO: Implement this method
	}
}
