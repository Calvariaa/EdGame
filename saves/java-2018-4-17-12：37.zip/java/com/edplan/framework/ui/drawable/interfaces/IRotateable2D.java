package com.edplan.framework.ui.drawable.interfaces;

public interface IRotateable2D
{
	/**
	 *@param ang:2pi制
	 */
	public void setRotation(float ang);
	
	public float getRotation();
}
