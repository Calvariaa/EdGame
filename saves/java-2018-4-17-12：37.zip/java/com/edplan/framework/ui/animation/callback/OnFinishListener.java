package com.edplan.framework.ui.animation.callback;

public interface OnFinishListener
{
	public void onFinish();
}
