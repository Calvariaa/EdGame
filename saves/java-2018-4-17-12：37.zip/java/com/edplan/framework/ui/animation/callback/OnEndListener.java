package com.edplan.framework.ui.animation.callback;

public interface OnEndListener
{
	public void onEnd();
}
