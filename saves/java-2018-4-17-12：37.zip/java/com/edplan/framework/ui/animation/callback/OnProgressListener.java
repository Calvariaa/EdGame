package com.edplan.framework.ui.animation.callback;

public interface OnProgressListener
{
	public void onProgress(double p);
}
