package com.edplan.framework.ui.animation.callback;

public interface OnStartListener
{
	public void onStart();
}
