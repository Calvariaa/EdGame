package com.edplan.framework.ui.animation.interpolate;

public interface Interplateable<T>
{
	public ValueInterpolator<T> getInterpolator();
}
