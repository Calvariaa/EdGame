package com.edplan.framework.ui.animation.interpolate;

public interface IInterpolator
{
	public double applyInterpolate(double v);
}
