package com.edplan.framework.ui.animation.precise;

public class AnimHelper
{
	public static class Fade{
		
	}
}
