package com.edplan.framework.ui.looper;
import com.edplan.superutils.interfaces.Loopable;

public abstract class StepedLoopable extends Loopable
{
	public abstract int getStep();
}
