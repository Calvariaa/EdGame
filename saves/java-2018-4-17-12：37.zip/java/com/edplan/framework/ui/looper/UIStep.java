package com.edplan.framework.ui.looper;

public class UIStep
{
	public static final int HANDLE_RUNNABLES=1;
	
	public static final int HANDLE_OTHER_LOOPABLE=2;

	public static final int HANDLE_ANIMATION=3;
	
	public static final int MESURE_CONTENT=4;
	
	public static final int DRAW_CONTENT=5;
}
