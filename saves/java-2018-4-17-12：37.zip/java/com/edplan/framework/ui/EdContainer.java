package com.edplan.framework.ui;


/**
 *单独绘制一个FBO，然后再绘制到父View上，可以附加边缘效果
 */
public class EdContainer
{
	
}
