package com.edplan.framework.inputs.cursor;
import com.edplan.framework.inputs.MAction;

public class MCursorAction implements MAction
{
	
}
