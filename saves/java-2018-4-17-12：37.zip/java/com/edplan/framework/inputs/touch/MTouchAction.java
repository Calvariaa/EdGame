package com.edplan.framework.inputs.touch;
import com.edplan.framework.inputs.MAction;

public class MTouchAction implements MAction
{
	
}
