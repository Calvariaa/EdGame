package com.edplan.framework.inputs.keyboard;
import com.edplan.framework.inputs.MActionHandler;

public interface MKeyBoardActionHandler extends MActionHandler<MKeyAction>
{
}
