package com.edplan.framework.inputs.keyboard;

import com.edplan.framework.inputs.MAction;

public class MKeyAction implements MAction
{
	
}
