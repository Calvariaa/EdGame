package com.edplan.framework.inputs;

public interface MAction
{
	
}
