package com.edplan.framework.inputs;

public class NativeInputsReflection
{
}