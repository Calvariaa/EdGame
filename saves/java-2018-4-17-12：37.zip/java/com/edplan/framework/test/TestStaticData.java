package com.edplan.framework.test;
import com.edplan.framework.math.Vec2;

public class TestStaticData
{
	public static Vec2 touchPosition=new Vec2();
}
