package com.edplan.framework.math;

public class Mat3
{
}