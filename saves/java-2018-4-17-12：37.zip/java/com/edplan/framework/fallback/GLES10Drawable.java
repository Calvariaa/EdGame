package com.edplan.framework.fallback;
import android.opengl.GLES10;
import com.edplan.framework.graphics.opengl.GL10Canvas2D;

public interface GLES10Drawable
{
	public void drawGL10(GL10Canvas2D canvas);
}
