package com.edplan.framework;

import android.app.Activity;

public class Application extends Activity 
{
	
	public Application(){
		
	}
	
	
}
