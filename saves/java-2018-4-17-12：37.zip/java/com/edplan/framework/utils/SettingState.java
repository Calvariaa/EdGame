package com.edplan.framework.utils;
import com.edplan.framework.interfaces.Copyable;

public abstract class SettingState implements Copyable
{
	public abstract void set();
}
