package com.edplan.framework.utils;

public class SystemUtil
{
	public static float getTimeFloat(){
		return 0;
	}
}
