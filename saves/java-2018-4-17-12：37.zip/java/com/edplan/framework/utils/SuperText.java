package com.edplan.framework.utils;

public class SuperText
{
	public static final String
	         MEDAL="🏅",
	         HEART="♥️",
	       SETTING="⚙️",
	          PICK="⛏️",
	        ROCKET="🚀",
	           DVD="💿",
	JACK_O_LANTERN="🎃",
	        CANDLE="🕯️",
	    LIGHT_BULB="💡",
	          BOOK="📕",
	         PAPER="📃",
   ROLLED_UP_PAPER="🗞️",
	      BOOKMARK="🔖",
	       PACKAGE="📦",
	           KEY="🔑",
	 CROSSED_SWORD="⚔️",
	        SHIELD="🛡️",
	          PILL="💊",
	  CRYSTAL_BALL="🔮";
	
	public static final String[] NUM_PLACE_MEDAL=new String[]{"🥇","🥈","🥉"};
	
	
}
