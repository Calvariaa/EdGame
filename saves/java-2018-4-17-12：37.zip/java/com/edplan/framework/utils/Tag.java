package com.edplan.framework.utils;

public @interface Tag
{
	public String value();
}
