package com.edplan.framework.animation;

public interface AnimaAdapter
{
	public void setProgress(float p);
}
