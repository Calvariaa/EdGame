package com.edplan.framework.animation;

public interface AnimaInterpolator
{
	public float getInterpolation(float f);
}
