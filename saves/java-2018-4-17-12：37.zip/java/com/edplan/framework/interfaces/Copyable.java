package com.edplan.framework.interfaces;

public interface Copyable
{
	public Copyable copy();
}
