package com.edplan.framework.interfaces;

public interface Reflection<T,K>
{
	public K invoke(T t);
}
