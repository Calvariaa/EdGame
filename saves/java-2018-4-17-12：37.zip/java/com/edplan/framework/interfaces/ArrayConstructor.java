package com.edplan.framework.interfaces;

public interface ArrayConstructor<T>
{
	public T[] create(int size);
}
