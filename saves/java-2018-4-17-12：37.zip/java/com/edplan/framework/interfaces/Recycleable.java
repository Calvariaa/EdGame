package com.edplan.framework.interfaces;

public interface Recycleable
{
	public void recycle();
}
