package com.edplan.framework.interfaces;

public interface Setable<T>
{
	public void set(T t);
}
