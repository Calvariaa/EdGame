package com.edplan.framework.interfaces;

public interface Getter<T>
{
	public T get();
}
