package com.edplan.framework.interfaces;

public interface Setter<T>
{
	public void set(T t);
}
