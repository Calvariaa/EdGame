package com.edplan.framework.interfaces;

public interface Function<T>
{
	public void invoke(T t);
}
