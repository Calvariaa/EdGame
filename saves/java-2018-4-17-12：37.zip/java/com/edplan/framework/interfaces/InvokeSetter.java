package com.edplan.framework.interfaces;

public interface InvokeSetter<T,V>
{
	public void invoke(T target,V value);
}
