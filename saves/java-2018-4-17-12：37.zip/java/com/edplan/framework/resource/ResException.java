package com.edplan.framework.resource;

public class ResException extends RuntimeException
{
	public ResException(String msg){
		super(msg);
	}
}
