package com.edplan.framework.resource;

public class DefR
{
	public static final String shaders="shaders";
	
	public static final String textures="textures";
}
