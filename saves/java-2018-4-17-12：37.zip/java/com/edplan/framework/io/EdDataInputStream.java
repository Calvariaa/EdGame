package com.edplan.framework.io;
import java.io.DataInputStream;

public class EdDataInputStream
{
	private DataInputStream in;
	
}
