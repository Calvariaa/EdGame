package com.edplan.framework.io;
import java.io.InputStream;

public class TestInputStream
{
	public TestInputStream(InputStream in){
		
	}
}
