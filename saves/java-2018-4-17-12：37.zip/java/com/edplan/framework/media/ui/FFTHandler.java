package com.edplan.framework.media.ui;
import com.edplan.framework.media.bass.BassChannel;

public interface FFTHandler 
{
	public void setChannel(BassChannel bass);
}
