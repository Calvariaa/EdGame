package com.edplan.framework.media.video.tbv;

public class TBVException extends Exception
{
	public TBVException(String msg){
		super(msg);
	}
	
	//public TBVException
}
