package com.edplan.framework.media.video.tbv;

public class TBVJson
{
	public static String OperatCanvas="OperatCanvas";
}
