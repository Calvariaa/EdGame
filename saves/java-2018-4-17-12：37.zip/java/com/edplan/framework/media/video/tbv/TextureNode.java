package com.edplan.framework.media.video.tbv;
import com.edplan.framework.graphics.opengl.objs.AbstractTexture;

public class TextureNode
{
	public String texture;
	public int id;
}
