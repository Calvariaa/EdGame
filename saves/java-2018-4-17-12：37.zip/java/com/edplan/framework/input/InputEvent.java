package com.edplan.framework.input;

public class InputEvent
{
	private int eventTime;

	public void setEventTime(int eventTime) {
		this.eventTime=eventTime;
	}

	public int getEventTime() {
		return eventTime;
	}
}
