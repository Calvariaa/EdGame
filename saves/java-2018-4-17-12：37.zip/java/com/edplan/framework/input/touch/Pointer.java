package com.edplan.framework.input.touch;
import com.edplan.framework.math.Vec2;
import java.util.ArrayList;

public class Pointer
{
	private int id;
	
	private Vec2 currentPosition;
	
	private ArrayList<Vec2> historicalPositions;
	
	
	
}
