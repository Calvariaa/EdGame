package com.edplan.framework.input.touch;

public class TouchEvent
{
	private Pointer[] pointers;
	
}
