package com.edplan.framework.graphics.line;

import com.edplan.framework.math.Vec2;
import java.util.Iterator;

public class PathIterator implements Iterator<Vec2> 
{
	
	
	@Override
	public boolean hasNext() {
		// TODO: Implement this method
		return false;
	}

	@Override
	public Vec2 next() {
		// TODO: Implement this method
		return null;
	}

	@Override
	public void remove() {
		// TODO: Implement this method
	}
}
