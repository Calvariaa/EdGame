package com.edplan.framework.graphics.opengl.batch;

import com.edplan.framework.graphics.opengl.buffer.Vec2Buffer;
import com.edplan.framework.graphics.opengl.buffer.Vec3Buffer;
import com.edplan.framework.graphics.opengl.objs.vertex.RectVertex;
import com.edplan.framework.graphics.opengl.batch.base.IHasRectPosition;
import com.edplan.framework.utils.Constructor;
import com.edplan.framework.interfaces.ArrayConstructor;

public class RectVertexBatch<T extends RectVertex> extends Texture3DBatch<T> implements IHasRectPosition
{
	protected RectVertexBatch(Constructor<T> c,ArrayConstructor<T> ac){
		super(c,ac);
	}
	
	private Vec2Buffer rectPositionBuffer=new Vec2Buffer();
	@Override
	public Vec2Buffer makeRectPositionBuffer(){
		rectPositionBuffer.clear();
		for(T t:vertexs){
			rectPositionBuffer.add(t.getRectPosition());
		}
		return rectPositionBuffer;
	}
	
	public static RectVertexBatch<RectVertex> create(){
		return new RectVertexBatch<RectVertex>(new Constructor<RectVertex>(){

				@Override
				public RectVertex createNewObject(Object[] args) {
					// TODO: Implement this method
					return new RectVertex();
				}
			}, new ArrayConstructor<RectVertex>(){

				@Override
				public RectVertex[] create(int size) {
					// TODO: Implement this method
					return new RectVertex[size];
				}
			});
	}
}
