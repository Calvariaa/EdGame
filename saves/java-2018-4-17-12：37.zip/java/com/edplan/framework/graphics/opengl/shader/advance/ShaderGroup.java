package com.edplan.framework.graphics.opengl.shader.advance;

public class ShaderGroup
{
	
	public class RectShaders{
		
	}
}
