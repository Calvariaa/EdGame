package com.edplan.framework.graphics.opengl.batch.base;
import com.edplan.framework.graphics.opengl.buffer.Vec3Buffer;

public interface IHasPosition
{
	public Vec3Buffer makePositionBuffer();
}
