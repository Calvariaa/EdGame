package com.edplan.framework.graphics.opengl;
import com.edplan.superutils.classes.MLooper;

public class GLLooper extends MLooper
{
}
