package com.edplan.framework.graphics.opengl.objs.advanced;
import com.edplan.framework.graphics.opengl.objs.TextureVertex3D;

public class TextureVertex3DTriangle
{
	public TextureVertex3D[] vertexs=new TextureVertex3D[3];
}
