package com.edplan.framework.graphics.opengl.objs;
import com.edplan.framework.math.Vec3;

public class Triangle
{
	public Vec3 p1,p2,p3;
	
	public Triangle(Vec3 p1,Vec3 p2,Vec3 p3){
		this.p1=p1;
		this.p2=p2;
		this.p3=p3;
	}
}
