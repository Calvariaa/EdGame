package com.edplan.framework.graphics.opengl.batch;

public abstract class BaseBatch
{
	public abstract int getVertexCount();
}
