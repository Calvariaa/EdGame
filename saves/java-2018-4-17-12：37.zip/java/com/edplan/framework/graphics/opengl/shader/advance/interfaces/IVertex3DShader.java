package com.edplan.framework.graphics.opengl.shader.advance.interfaces;

public interface IVertex3DShader
{
	public void loadVertexs();
}
