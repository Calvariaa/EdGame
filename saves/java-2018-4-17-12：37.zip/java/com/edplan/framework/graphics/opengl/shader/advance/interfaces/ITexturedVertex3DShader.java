package com.edplan.framework.graphics.opengl.shader.advance.interfaces;


import com.edplan.framework.graphics.opengl.batch.Texture3DBatch;

public interface ITexturedVertex3DShader 
{
	public void loadBatch(Texture3DBatch batch);
}
