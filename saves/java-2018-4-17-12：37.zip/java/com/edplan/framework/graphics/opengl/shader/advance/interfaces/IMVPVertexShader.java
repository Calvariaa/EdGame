package com.edplan.framework.graphics.opengl.shader.advance.interfaces;
import com.edplan.framework.math.Mat4;

public interface IMVPVertexShader
{
	public void loadMVPMatrix(Mat4 m);
}
