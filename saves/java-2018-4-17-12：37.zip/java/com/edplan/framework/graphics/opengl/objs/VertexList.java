package com.edplan.framework.graphics.opengl.objs;

public interface VertexList<V extends Vertex3D>
{
	public V[] listVertex();
}
