package com.edplan.framework.graphics.opengl.shader.advance.interfaces;
import com.edplan.framework.graphics.opengl.objs.GLTexture;

public interface IStandardTextureFragmentShader
{
	public void loadTexture(GLTexture tex);
}
