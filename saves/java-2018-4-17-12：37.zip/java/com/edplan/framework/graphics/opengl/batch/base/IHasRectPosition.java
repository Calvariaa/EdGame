package com.edplan.framework.graphics.opengl.batch.base;
import com.edplan.framework.graphics.opengl.buffer.Vec2Buffer;

public interface IHasRectPosition
{
	public Vec2Buffer makeRectPositionBuffer();
}
