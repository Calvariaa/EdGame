package com.edplan.framework.graphics.opengl.objs.texture;

public class DrawableTexture
{
}