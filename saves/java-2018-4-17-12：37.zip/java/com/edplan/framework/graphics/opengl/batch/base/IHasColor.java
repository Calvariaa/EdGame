package com.edplan.framework.graphics.opengl.batch.base;
import com.edplan.framework.graphics.opengl.buffer.Color4Buffer;

public interface IHasColor
{
	public Color4Buffer makeColorBuffer();
}
