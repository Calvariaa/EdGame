package com.edplan.nso.filepart;

public class PropertList
{
	public void setPropert(String key,String value){
		
	}
}
