package com.edplan.nso.filepart;

public interface PropertySetter<T>
{
	public void set(T t,String value);
}
