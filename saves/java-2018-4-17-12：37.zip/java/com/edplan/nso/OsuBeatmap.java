package com.edplan.nso;
import com.edplan.nso.storyboard.Storyboard;


public abstract class OsuBeatmap
{
	private Storyboard storyboard;

	public void setStoryboard(Storyboard storyboard) {
		this.storyboard=storyboard;
	}

	public Storyboard getStoryboard() {
		return storyboard;
	}
	
	//public boolean hasStoryboard(){}
	
	public void getRuleset(){
		
	}
}
