package com.edplan.nso;

public class StrR
{
	public static String DEF_MAP_TITLE="unknow title";
	public static String DEF_MAP_ARTIST="unknow artist";
	public static String DEF_MAP_CREATOR="unknow creator";
}
