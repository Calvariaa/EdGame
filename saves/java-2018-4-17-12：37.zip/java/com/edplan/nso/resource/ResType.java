package com.edplan.nso.resource;

public enum ResType
{
	TEXTURE,
	AUDIO,
	TXT,
	INI,
	BINARY,
	TEXTUREFONT,
	FRAMETEXTURE
}
