package com.edplan.nso.storyboard.elements;

public interface ICommandTimeLine
{
	public double getStartTime();
	public double getEndTime();
	public boolean hasCommands();
}
