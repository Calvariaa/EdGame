package com.edplan.nso;
import com.edplan.superutils.interfaces.StringMakeable;

public interface OsuFilePart extends StringMakeable
{
	public String getTag();
}
