package com.edplan.nso.ruleset.std.playing.controlpoint;

public class SampleControlPoint extends ControlPoint
{
}
