package com.edplan.nso.ruleset.std.objects;

public class StdHitCircle extends StdHitObject
{

	@Override
	public StdHitObjectType getResType(){
		// TODO: Implement this method
		return StdHitObjectType.Circle;
	}
}
