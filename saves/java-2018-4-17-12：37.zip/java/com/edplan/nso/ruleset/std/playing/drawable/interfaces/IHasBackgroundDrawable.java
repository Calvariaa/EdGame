package com.edplan.nso.ruleset.std.playing.drawable.interfaces;
import com.edplan.nso.ruleset.std.playing.drawable.DrawableStdHitObject;
import com.edplan.framework.ui.drawable.EdDrawable;

public interface IHasBackgroundDrawable
{
	public EdDrawable getBackgroundDrawable();
}
