package com.edplan.nso.ruleset.std.playing.controlpoint;

public class ControlPoint
{
	private int time;


	public void setTime(int time) {
		this.time=time;
	}

	public int getTime() {
		return time;
	}
	
}
