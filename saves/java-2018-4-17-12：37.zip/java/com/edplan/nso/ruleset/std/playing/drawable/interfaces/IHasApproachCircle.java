package com.edplan.nso.ruleset.std.playing.drawable.interfaces;
import com.edplan.nso.ruleset.std.playing.drawable.piece.ApproachCircle;

public interface IHasApproachCircle
{
	public ApproachCircle getApproachCircle();
}
