package com.edplan.nso.ruleset.mania.objects;
import com.edplan.nso.ruleset.std.objects.StdHitObject;

public abstract class ManiaHitObject extends StdHitObject
{
	
}
