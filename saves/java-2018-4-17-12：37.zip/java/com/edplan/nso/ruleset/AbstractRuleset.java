package com.edplan.nso.ruleset;

public class AbstractRuleset
{
	public static AbstractRuleset fromMode(int mode){
		return null;
	}
}
