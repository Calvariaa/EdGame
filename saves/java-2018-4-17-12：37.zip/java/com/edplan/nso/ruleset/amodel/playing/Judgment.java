package com.edplan.nso.ruleset.amodel.playing;

public class Judgment
{
	/**
	 *基于PreciseTimeLine的时间
	 */
	private float resTime;

	public void setResTime(float resTime) {
		this.resTime=resTime;
	}

	public float getResTime() {
		return resTime;
	}
}
