package com.edplan.nso.ruleset.amodel.object;

public class HitObject
{
}
