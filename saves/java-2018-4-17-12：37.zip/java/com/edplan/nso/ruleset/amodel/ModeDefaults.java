package com.edplan.nso.ruleset.amodel;

public class ModeDefaults
{
}
