package com.edplan.nso.osb.base;
import com.edplan.framework.math.Vec2;

public class OsbObject
{
	
	
	public Vec2 point;
	
}
