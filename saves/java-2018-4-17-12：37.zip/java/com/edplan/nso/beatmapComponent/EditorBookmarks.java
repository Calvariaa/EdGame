package com.edplan.nso.beatmapComponent;
import com.edplan.superutils.interfaces.StringMakeable;

public class EditorBookmarks implements StringMakeable
{

	@Override
	public String makeString(){
		// TODO: Implement this method
		return "{@Bookmarks}";
	}
}
