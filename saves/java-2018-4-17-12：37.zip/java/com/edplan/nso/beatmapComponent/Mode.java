package com.edplan.nso.beatmapComponent;

public class Mode
{
}