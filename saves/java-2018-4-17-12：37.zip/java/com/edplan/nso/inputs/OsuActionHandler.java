package com.edplan.nso.inputs;
import com.edplan.framework.inputs.MActionHandler;

public abstract class OsuActionHandler implements MActionHandler
{
	
}
