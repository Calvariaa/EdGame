package com.edplan.mygame.stages;
import com.edplan.framework.view.Stage;
import com.edplan.framework.MContext;

public class MainStage extends Stage
{
	public MainStage(MContext con){
		super(con);
	}
}
