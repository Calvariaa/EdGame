package com.edplan.superutils.classes.graphics;
import android.graphics.Bitmap;

public interface AbstractBitmapReference
{
	public Bitmap getBitmap();
}
