package com.edplan.superutils.interfaces;

public interface TimeBasedObject
{
	public void setTime(int time);
	
	public int getTime();
}
