package com.edplan.superutils.interfaces;

public interface StringMakeable
{
	public String makeString();
}
